package com.example.pr14;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
public class Main2 extends AppCompatActivity implements View.OnClickListener  {
View view;
View flat;
ImageView menu;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        view = findViewById(R.id.view_trening);
        view.setOnClickListener(this);
        flat=findViewById(R.id.imageView3);
        flat.setOnClickListener(this);
        menu = findViewById(R.id.imageView5);
        menu.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.view_trening) {
            Intent intent = new Intent(this, Trening.class);
            startActivity(intent);
        }
        else if (view.getId() == R.id.imageView3) {
            Intent track = new Intent(this, Statistic.class);
            startActivity(track);
        }
        else if(view.getId()==R.id.imageView5){
            Intent menu = new Intent(this, menu.class);
            startActivity(menu);
        }
    }
}