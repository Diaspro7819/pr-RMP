package com.example.pr_9egorovapr_211012;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Steps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steps);
    }
}